
from telegram import Update, ChatPermissions
from telegram.ext import ApplicationBuilder, MessageHandler, filters, CommandHandler, ContextTypes, ChatMemberHandler

# 🔑 أدخل التوكن هنا
TOKEN = "7536792961:AAE56cek-NBdkGL0OElRB1XCwy8cLigiV7U"

# 🛑 قائمة الكلمات الممنوعة
BANNED_WORDS = ["نصاب", "سراق", "spam", "رابط", "سراق", "منتحل"]

# ✅ رسالة الترحيب
WELCOME_MESSAGE = "👋 أهلًا وسهلًا بك في المجموعة يا {} 🌟"

# 📌 أمر /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🤖 بوت الحماية مفعل ويعمل الآن!")

# 🧼 فحص الرسائل للكلمات الممنوعة
async def filter_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.lower()
    if any(bad_word in text for bad_word in BANNED_WORDS):
        try:
            await update.message.delete()
            await update.message.reply_text("⚠️ تم حذف رسالتك لأنها تحتوي كلمات غير مسموح بها.", quote=True)
        except:
            pass

# ✨ ترحيب بالعضو الجديد
async def welcome(update: Update, context: ContextTypes.DEFAULT_TYPE):
    for member in update.message.new_chat_members:
        await update.message.reply_text(WELCOME_MESSAGE.format(member.full_name))

# 🚀 تشغيل البوت
app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, welcome))
app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), filter_messages))

app.run_polling()
