
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters, CommandHandler, ContextTypes

TOKEN = "7536792961:AAEZqrUorwoUR0YnLEtsF3NiJN6GFDmWZOM"
BANNED_WORDS = ["نصاب", "سراق", "سارق", "نصب"]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋مرحبًا! أنا بوت الحمايةلجروب الصرافة")

async def check_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.lower()
    if any(word in text for word in BANNED_WORDS):
        await update.message.delete()

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), check_message))

app.run_polling()
